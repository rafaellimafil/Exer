// Aleth: Ethereum C++ client, tools and libraries.
// Copyright 2014-2019 Aleth Authors.
// Licensed under the GNU General Public License, Version 3.


#include "GasPricer.h"

using namespace std;
using namespace dev;
using namespace dev::eth;
