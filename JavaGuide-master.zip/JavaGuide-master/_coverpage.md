<p align="center">
<img src="./media/pictures/logo.png" width="200" height="200"/>
</p>


<h1 align="center">Java 学习/面试指南</h1>

[常用资源](https://shimo.im/docs/MuiACIg1HlYfVxrj/)
[GitHub](<https://github.com/Snailclimb/JavaGuide>)
[开始阅读](#java)


