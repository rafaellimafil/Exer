<!-- Thank you for your interest in Awesome JavaScript 🎉 -->

<!-- These comment lines are only here to guide you, and will not be visible in the pull request you're about to create. -->

Checklist:

- [ ] I've read and understood [Contributing Guidelines](CONTRIBUTING.md).
- [ ] I've added the new resource at the end of its section.
- [ ] This resource is out there for a while, and actively maintained.
- [ ] This resource is popular enough and has at least a few hundred stars on GitHub.

---

<!-- Please explain what this new addition is about, and why it should be included here with your own words. -->

...
