This directory contains Code Composer Studio projects for V7 examples.

When importing, make sure the "Copy projects into workspace" checkbox is *not* checked.
