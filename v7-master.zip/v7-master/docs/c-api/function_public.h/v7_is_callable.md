---
title: "v7_is_callable()"
decl_name: "v7_is_callable"
symbol_kind: "func"
signature: |
  int v7_is_callable(struct v7 *v7, v7_val_t v);
---

Returns true if given value is callable (i.e. it's either a JS function or
cfunction) 

