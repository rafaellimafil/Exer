---
title: "Functions"
symbol_kind: "intro"
decl_name: "function_public.h"
items:
  - { name: v7_is_callable.md }
  - { name: v7_mk_cfunction.md }
  - { name: v7_mk_function.md }
  - { name: v7_mk_function_with_proto.md }
---



