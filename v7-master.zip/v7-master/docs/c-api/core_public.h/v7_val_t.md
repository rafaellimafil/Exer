---
title: "v7_val_t"
decl_name: "v7_val_t"
symbol_kind: "typedef"
signature: |
  typedef uint64_t v7_val_t;
---

64-bit value, used to store JS values 

