---
title: "v7_argc()"
decl_name: "v7_argc"
symbol_kind: "func"
signature: |
  unsigned long v7_argc(struct v7 *v7);
---

Return the length of `arguments` 

