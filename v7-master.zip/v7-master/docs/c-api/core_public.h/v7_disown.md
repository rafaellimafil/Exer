---
title: "v7_disown()"
decl_name: "v7_disown"
symbol_kind: "func"
signature: |
  int v7_disown(struct v7 *v7, v7_val_t *v);
---

Returns 1 if value is found, 0 otherwise 

