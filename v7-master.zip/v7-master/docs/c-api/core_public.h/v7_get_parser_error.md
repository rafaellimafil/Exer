---
title: "v7_get_parser_error()"
decl_name: "v7_get_parser_error"
symbol_kind: "func"
signature: |
  const char *v7_get_parser_error(struct v7 *v7);
---

Returns last parser error message. TODO: rename it to `v7_get_error()` 

