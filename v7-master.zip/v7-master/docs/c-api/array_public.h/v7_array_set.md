---
title: "v7_array_set()"
decl_name: "v7_array_set"
symbol_kind: "func"
signature: |
  int v7_array_set(struct v7 *v7, v7_val_t arr, unsigned long index, v7_val_t v);
---

Insert value `v` into `arr` at index `index`. 

