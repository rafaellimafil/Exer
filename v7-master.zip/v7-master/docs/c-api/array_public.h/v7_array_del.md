---
title: "v7_array_del()"
decl_name: "v7_array_del"
symbol_kind: "func"
signature: |
  void v7_array_del(struct v7 *v7, v7_val_t arr, unsigned long index);
---

Delete value in array `arr` at index `index`, if it exists. 

