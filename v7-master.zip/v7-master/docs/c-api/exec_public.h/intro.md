---
title: "Execution of JavaScript code"
symbol_kind: "intro"
decl_name: "exec_public.h"
items:
  - { name: v7_apply.md }
  - { name: v7_compile.md }
  - { name: v7_exec.md }
  - { name: v7_exec_buf.md }
  - { name: v7_exec_file.md }
  - { name: v7_exec_opt.md }
  - { name: v7_parse_json.md }
  - { name: v7_parse_json_file.md }
  - { name: struct_v7_exec_opts.md }
---



