---
title: "Exceptions"
symbol_kind: "intro"
decl_name: "exceptions_public.h"
items:
  - { name: v7_clear_thrown_value.md }
  - { name: v7_get_thrown_value.md }
  - { name: v7_rethrow.md }
  - { name: v7_throw.md }
  - { name: v7_throwf.md }
---



