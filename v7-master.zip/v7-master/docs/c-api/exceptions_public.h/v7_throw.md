---
title: "v7_throw()"
decl_name: "v7_throw"
symbol_kind: "func"
signature: |
  enum v7_err v7_throw(struct v7 *v7, v7_val_t v);
---

Throw an exception with an already existing value. 

