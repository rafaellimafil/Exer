---
title: "v7_is_regexp()"
decl_name: "v7_is_regexp"
symbol_kind: "func"
signature: |
  int v7_is_regexp(struct v7 *v7, v7_val_t v);
---

Returns true if given value is a JavaScript RegExp object 

