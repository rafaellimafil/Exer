---
title: "RegExp"
symbol_kind: "intro"
decl_name: "regexp_public.h"
items:
  - { name: v7_is_regexp.md }
  - { name: v7_mk_regexp.md }
---



