---
title: "Utility functions"
symbol_kind: "intro"
decl_name: "util_public.h"
items:
  - { name: v7_fprint.md }
  - { name: v7_fprint_stack_trace.md }
  - { name: v7_fprintln.md }
  - { name: v7_mk_proxy.md }
  - { name: v7_print.md }
  - { name: v7_print_error.md }
  - { name: v7_println.md }
  - { name: v7_get_own_prop_desc_cb_t.md }
---



