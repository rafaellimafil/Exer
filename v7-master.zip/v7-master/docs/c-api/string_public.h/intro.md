---
title: "Strings"
symbol_kind: "intro"
decl_name: "string_public.h"
items:
  - { name: v7_get_cstring.md }
  - { name: v7_get_string.md }
  - { name: v7_is_string.md }
  - { name: v7_mk_string.md }
---



