---
title: "Conversion"
symbol_kind: "intro"
decl_name: "conversion_public.h"
items:
  - { name: v7_is_truthy.md }
  - { name: v7_stringify.md }
  - { name: v7_stringify_throwing.md }
  - { name: v7_to_json.md }
  - { name: enum_v7_stringify_mode.md }
---



