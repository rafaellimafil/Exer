---
title: "v7_is_truthy()"
decl_name: "v7_is_truthy"
symbol_kind: "func"
signature: |
  int v7_is_truthy(struct v7 *v7, v7_val_t v);
---

Returns true if given value evaluates to true, as in `if (v)` statement. 

