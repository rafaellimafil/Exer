---
title: "enum v7_stringify_mode"
decl_name: "enum v7_stringify_mode"
symbol_kind: "enum"
signature: |
  enum v7_stringify_mode {
    V7_STRINGIFY_DEFAULT,
    V7_STRINGIFY_JSON,
    V7_STRINGIFY_DEBUG,
  };
  
---

Stringify mode, see `v7_stringify()` and `v7_stringify_throwing()` 

