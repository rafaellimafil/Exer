---
title: "v7_destruct_prop_iter_ctx()"
decl_name: "v7_destruct_prop_iter_ctx"
symbol_kind: "func"
signature: |
  void v7_destruct_prop_iter_ctx(struct v7 *v7, struct prop_iter_ctx *ctx);
---

Destruct the property iteration context `ctx`, see `v7_next_prop()` for
usage example 

