---
title: "v7_is_instanceof_v()"
decl_name: "v7_is_instanceof_v"
symbol_kind: "func"
signature: |
  int v7_is_instanceof_v(struct v7 *v7, v7_val_t o, v7_val_t c);
---

Returns true if the object is an instance of a given constructor. 

