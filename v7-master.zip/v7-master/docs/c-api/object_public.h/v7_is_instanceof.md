---
title: "v7_is_instanceof()"
decl_name: "v7_is_instanceof"
symbol_kind: "func"
signature: |
  int v7_is_instanceof(struct v7 *v7, v7_val_t o, const char *c);
---

Returns true if the object is an instance of a given constructor. 

