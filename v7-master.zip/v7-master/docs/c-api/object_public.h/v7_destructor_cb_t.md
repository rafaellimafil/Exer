---
title: "v7_destructor_cb_t"
decl_name: "v7_destructor_cb_t"
symbol_kind: "typedef"
signature: |
  typedef void(v7_destructor_cb_t)(struct v7 *v7, void *ud);
---

See `v7_set_destructor_cb` 

