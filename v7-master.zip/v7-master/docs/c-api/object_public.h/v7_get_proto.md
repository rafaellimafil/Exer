---
title: "v7_get_proto()"
decl_name: "v7_get_proto"
symbol_kind: "func"
signature: |
  v7_val_t v7_get_proto(struct v7 *v7, v7_val_t obj);
---

Get object's prototype. 

