---
title: "Garbage Collector"
symbol_kind: "intro"
decl_name: "gc_public.h"
items:
  - { name: v7_gc.md }
  - { name: v7_heap_stat.md }
  - { name: enum_v7_heap_stat_what.md }
---



