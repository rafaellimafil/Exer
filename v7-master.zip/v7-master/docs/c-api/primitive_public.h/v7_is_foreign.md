---
title: "v7_is_foreign()"
decl_name: "v7_is_foreign"
symbol_kind: "func"
signature: |
  int v7_is_foreign(v7_val_t v);
---

Returns true if given value holds `void *` pointer 

