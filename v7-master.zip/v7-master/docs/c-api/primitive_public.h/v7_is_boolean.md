---
title: "v7_is_boolean()"
decl_name: "v7_is_boolean"
symbol_kind: "func"
signature: |
  int v7_is_boolean(v7_val_t v);
---

Returns true if given value is a primitive boolean value 

