---
title: "v7_mk_undefined()"
decl_name: "v7_mk_undefined"
symbol_kind: "func"
signature: |
  NOINSTR v7_val_t v7_mk_undefined(void);
---

Make `undefined` primitive value.

NOTE: this function is deprecated and will be removed in future releases.
Use `V7_UNDEFINED` instead. 

