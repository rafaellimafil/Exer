---
title: "v7_mk_number()"
decl_name: "v7_mk_number"
symbol_kind: "func"
signature: |
  NOINSTR v7_val_t v7_mk_number(struct v7 *v7, double num);
---

Make numeric primitive value 

