---
title: "v7_mk_boolean()"
decl_name: "v7_mk_boolean"
symbol_kind: "func"
signature: |
  NOINSTR v7_val_t v7_mk_boolean(struct v7 *v7, int is_true);
---

Make boolean primitive value (either `true` or `false`) 

