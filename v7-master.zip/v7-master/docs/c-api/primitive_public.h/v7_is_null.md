---
title: "v7_is_null()"
decl_name: "v7_is_null"
symbol_kind: "func"
signature: |
  int v7_is_null(v7_val_t v);
---

Returns true if given value is a primitive `null` value 

