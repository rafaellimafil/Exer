---
title: Other
---

- `-DV7_CYG_PROFILE_ON` - It is automatically defined if any of the features
  which use cyg_profile instrumentation are enabled; users don't need to define
  it manually. Enables generic code of the cyg_profile instrumentation.
