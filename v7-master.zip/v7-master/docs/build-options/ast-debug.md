---
title: AST debug
---

- `-DV7_DISABLE_AST_TAG_NAMES` - Unless defined, V7 has constant names of
  each AST tag. It is only needed for dumping generated AST (the `-t` flag).
