---
title: Build options
items:
  - { type: file, name: options.md }
  - { type: file, name: features.md }
  - { type: file, name: error-reporting.md }
  - { type: file, name: bcode-debug.md }
  - { type: file, name: ast-debug.md }
  - { type: file, name: gc-debug.md }
  - { type: file, name: generic-debug.md }
  - { type: file, name: stack-tracing.md }
  - { type: file, name: call-tracing.md }
  - { type: file, name: freezing.md }
  - { type: file, name: other.md }
---
