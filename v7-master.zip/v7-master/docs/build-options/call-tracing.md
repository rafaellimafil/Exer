---
title: Call tracing
---

- `-DV7_ENABLE_CALL_TRACE` - If defined, V7 keeps track of every C function call.
  Used for example in heaplog; see `tools/heaplog_viewer/README.md`.
