---
title: Bcode debug
---

- `-DV7_BCODE_DUMP` - Enables bcode dump (TODO: it is broken at the moment).
- `-DV7_BCODE_TRACE` - Enables bcode trace (TODO: it is broken at the moment).
- `-DV7_BCODE_TRACE_STACK` - Enables even more verbose bcode tracing: after
  each opcode, the data stack will be dumped. Caution: it generates lots of
  output.
