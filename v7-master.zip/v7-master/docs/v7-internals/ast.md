---
title: AST
---

AST represents the program's syntax tree in a compact and portable binary form.
