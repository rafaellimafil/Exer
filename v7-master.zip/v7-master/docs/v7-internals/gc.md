---
title: Garbage Collector
---

GC and other memory optimisation techniques are described in this
[V7 memory optimisation tech talk](https://docs.cesanta.com/media/slides-v7_mem.html).
