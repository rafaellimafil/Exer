---
title: VM
---

The VM operates on several core data structures:

- `struct v7` - describes the V7 instance itself
- `struct v7_object`, `struct v7_property` - describes the object and its
   properties
- `struct ast` - describes AST, which VM executes
