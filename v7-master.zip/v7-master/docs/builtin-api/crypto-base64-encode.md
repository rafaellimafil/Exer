---
title: Crypto.base64_encode()
signature: |
  Crypto.base64_encode(str)
---

Base64-encodes input string `str` and returns encoded string.
