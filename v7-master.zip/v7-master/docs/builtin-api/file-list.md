---
title: File.list()
signature: |
  File.list(dir_name) -> array_of_names
---

Returns a list of files in a given directory or `undefined` on error.
