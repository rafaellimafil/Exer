---
title: Crypto.base64_decode()
signature: |
  Crypto.base64_decode(str)
---

Base64-decode inputs string `str` and returns decoded string.
