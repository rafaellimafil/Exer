---
title: File.rename()
signature: |
  File.rename(old_name, new_name) -> errno
---

Renames the file `old_name` to `new_name`. Returns 0 on success or `errno` value on
error.
