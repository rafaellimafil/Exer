---
title: socket_obj.accept()
signature: |
  socket_obj.accept() -> socket_obj
---

Sleeps until new incoming connection has arrived. Returns the accepted socket object
on success or `null` on error.
