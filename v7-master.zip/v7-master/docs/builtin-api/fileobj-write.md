---
title: file_obj.write()
signature: |
  file_obj.write(str) -> num_bytes_written
---

Writes a string `str` to the opened file object. Returns the number of bytes written.
