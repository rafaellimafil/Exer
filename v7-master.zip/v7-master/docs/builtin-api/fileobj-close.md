---
title: file_obj.close()
signature: |
  file_obj.close() -> undefined
---

Closes an opened file object.

NOTE: it is the user's responsibility to close all opened file streams. V7 does not
do that automatically.
