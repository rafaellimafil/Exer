---
title: socket_obj.recv()
signature: |
  socket_obj.recv() -> string
---

Reads data from socket. Returns data string or empty string if peer has
disconnected, or `null` on error.
