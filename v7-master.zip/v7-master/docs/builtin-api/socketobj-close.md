---
title: socket_obj.close()
signature: |
  socket_obj.close() -> numeric_errno
---

Closes the socket object. Returns 0 on success or a system errno on error.
