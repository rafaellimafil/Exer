---
title: File.remove()
signature: |
  File.remove(file_name) -> errno
---

Deletes the file `file_name`.

Returns 0 on success or `errno` value on error.
