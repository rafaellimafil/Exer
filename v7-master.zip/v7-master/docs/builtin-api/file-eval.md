---
title: File.eval()
signature: |
  File.eval(file_name)
---

Parses and runs `file_name`.

Throws an exception if the file doesn't exist, it cannot be parsed or if the
script throws any exception.
