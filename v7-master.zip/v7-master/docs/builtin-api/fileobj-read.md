---
title: file_obj.read()
signature: |
  file_obj.read() -> string
---

Reads a portion of data from an opened file stream. Returns a string with data or
an empty string on EOF or error.
