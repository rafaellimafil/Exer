---
title: Examples
items:
  - { type: file, name: c-from-js.md }
  - { type: file, name: js-from-c.md }
  - { type: file, name: load-json-config.md }

---
