//
//  main.m
//  Hello
//
//  Created by Tom Ball on 2/9/16.
//  Copyright © 2016 com.google. All rights reserved.
//

#import "AppDelegate.h"

#import <UIKit/UIKit.h>

int main(int argc, char * argv[]) {
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
  }
}
