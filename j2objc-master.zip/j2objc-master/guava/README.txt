Translates the Guava source jar and builds libguava.a.
