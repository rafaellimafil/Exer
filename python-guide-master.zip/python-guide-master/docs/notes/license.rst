#######
License
#######

.. image:: /_static/photos/32800805573_568d6b72fd_k_d.jpg

The Guide is licensed under the `Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported license <https://creativecommons.org/licenses/by-nc-sa/3.0/>`_.
