* Establish "use this" vs "alternatives are...." recommendations

.. todolist::