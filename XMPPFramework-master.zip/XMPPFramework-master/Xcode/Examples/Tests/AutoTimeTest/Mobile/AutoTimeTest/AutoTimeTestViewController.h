//
//  AutoTimeTestViewController.h
//  AutoTimeTest
//
//  Created by Robbie Hanson on 9/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AutoTimeTestViewController : UIViewController

@end
