//
//  main.m
//  ParserTestPhone
//
//  Created by Robbie Hanson on 11/22/09.
//  Copyright Deusty Designs, LLC. 2009. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ParserTestPhoneAppDelegate.h"

int main(int argc, char *argv[]) {
    
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([ParserTestPhoneAppDelegate class]));
    }
}
