//
//  main.m
//  TestXEP82
//
//  Created by Robbie Hanson on 4/12/11.
//  Copyright 2011 Voalte. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TestXEP82AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([TestXEP82AppDelegate class]));
    }
}
