#import <Foundation/Foundation.h>

@interface NSString (XEP_0106)

@property (nonatomic, readonly, nullable) NSString * jidEscapedString;

@property (nonatomic, readonly, nullable) NSString * jidUnescapedString;

@end
