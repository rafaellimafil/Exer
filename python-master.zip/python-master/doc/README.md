Building the documentation
==========================

Install the test requirements with:

```
$ pip install -r ../test-requirements.txt
```

Use `make html` to build the docs in html format.

