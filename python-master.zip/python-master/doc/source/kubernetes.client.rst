kubernetes.client package
=========================

Subpackages
-----------

.. toctree::

    kubernetes.client.apis
    kubernetes.client.models

Submodules
----------

kubernetes.client.api_client module
-----------------------------------

.. automodule:: kubernetes.client.api_client
    :members:
    :undoc-members:
    :show-inheritance:

kubernetes.client.configuration module
--------------------------------------

.. automodule:: kubernetes.client.configuration
    :members:
    :undoc-members:
    :show-inheritance:

kubernetes.client.rest module
-----------------------------

.. automodule:: kubernetes.client.rest
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: kubernetes.client
    :members:
    :undoc-members:
    :show-inheritance:
