**Thanks for contributing to Awesome Ruby! Please take a look at the [contribution guidelines and quality standard](https://github.com/markets/awesome-ruby/blob/master/CONTRIBUTING.md) first and :scissors: remove this line.**

## Project

Title and urls (GitHub, RubyGems, project page, blog posts, ...).

## What is this Ruby project?

Describe features.

## What are the main difference between this Ruby project and similar ones?

Enumerate comparisons.

---

Please help us to maintain this collection by using reactions (:+1:, :-1:) and comments to express your feelings.